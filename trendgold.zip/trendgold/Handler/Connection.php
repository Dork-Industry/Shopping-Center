<?php

$local="localhost";
$user="root";
$pass="";
$Db="trending_gold";

$con=mysqli_connect($local,$user,$pass,$Db);



?>