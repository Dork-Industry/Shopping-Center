<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Trending Gold Items ">
  <meta name="keywords" content="Trending Gold Items ">
  
  <link rel="icon" href="../assets/images/favicon.png" type="image/x-icon">
  <link rel="shortcut icon" href="../assets/images/favicon.png" type="image/x-icon">
  <title>Trending Gold Admin Panel</title>

  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link type='text/css' rel='stylesheet' href='https://fonts.googleapis.com/css?family=Abhaya Libre'>
  
  <!-- Font Awesome-->
  <link rel="stylesheet" type="text/css" href="../assets/css/fontawesome.css">
  <!-- ico-font-->
  <link rel="stylesheet" type="text/css" href="../assets/css/icofont.css">
  <!-- Themify icon-->
  <link rel="stylesheet" type="text/css" href="../assets/css/themify.css">
  <!-- Flag icon-->
  <link rel="stylesheet" type="text/css" href="../assets/css/flag-icon.css">
  <!-- Feather icon-->
  <link rel="stylesheet" type="text/css" href="../assets/css/feather-icon.css">
  <!-- Plugins css start-->
  <link rel="stylesheet" type="text/css" href="../assets/css/animate.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/chartist.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/date-picker.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/prism.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/vector-map.css">
  <!-- Plugins css Ends-->
  <!-- Bootstrap css-->
  <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">
  <!-- App css-->
  <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
  <link id="color" rel="stylesheet" href="../assets/css/color-1.css" media="screen">
  <!-- Responsive css-->
  <link rel="stylesheet" type="text/css" href="../assets/css/responsive.css">
  <!-- <script type="text/javascript"
    src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=qBK1CmBxPTXxvQweuq_Z1UORQlKQy8Q8Bf-f19RHtdAbEp1SCBWNTKRx-lKvxHt8KfLE016smSa1-Qe_KNisHgD6f8uwY8FPA1TLUOWXk9c"
    charset="UTF-8"></script> -->
</head>
<body>






</body>
</html>