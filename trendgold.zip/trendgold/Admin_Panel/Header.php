<header class="main-nav">
                <div class="sidebar-user text-center"><a class="setting-primary" href="javascript:void(0)"><i
                            data-feather="settings"></i></a><img class="img-90 rounded-circle"
                        src="../assets/images/dashboard/1.png" alt="">
                    <div class="badge-bottom"><span class="badge badge-primary">New</span></div>
                    <a href="">
                        <h6 class="mt-3 f-14 f-w-600">Dork Industry</h6>
                    </a>
                    <p class="mb-0 font-roboto">Admin Department</p>
                    <ul>
                        <li><span><span class="counter">19.8</span>k</span>
                            <p>Follow</p>
                        </li>
                        <li><span>10 year</span>
                            <p>Experince</p>
                        </li>
                        <li><span><span class="counter">95.2</span>k</span>
                            <p>Follower </p>
                        </li>
                    </ul>
                </div>
                <nav>
                    <div class="main-navbar">
                        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
                        <div id="mainnav">
                            <ul class="nav-menu custom-scrollbar">
                                <li class="back-btn">
                                    <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2"
                                            aria-hidden="true"></i></div>
                                </li>
                                <li class="sidebar-main-title">
                                    <div>
                                        <h6>Services </h6>
                                    </div>
                                </li>
                                <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i
                                            data-feather="user"></i><span>Users</span></a>
                                    <ul class="nav-submenu menu-content">
                                        <li><a href="Add_User.php">

                                                <i data-feather="plus"></i>
                                                ADD</a></li>

                                        </a>
                                </li>


                                <li><a href="View_User.php">

                                        <i data-feather="eye"></i>
                                        VIEW</a></li>

                                </a></li>
                            </ul>
                            </li>

                            <li class="sidebar-main-title">
                                <div>
                                    <h6>Gold</h6>
                                </div>
                            </li>
                            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i
                                        data-feather="list"></i><span>Items</span></a>
                                <ul class="nav-submenu menu-content">
                                    <li><a href="Add_Item.php?Name=Gold">

                                            <i data-feather="plus"></i>
                                            ADD</a>

                                    </li>

                                    <li><a href="">

                                            <i data-feather="eye"></i>
                                            VIEW</a></li>
                            </li>

                            </ul>



                            </li>




                            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i
                                        data-feather="list"></i><span>Products</span></a>
                                <ul class="nav-submenu menu-content">
                                    <li><a href="Add_Product.php?Name=Gold">

                                            <i data-feather="plus"></i>
                                            ADD</a>

                                    </li>

                                    <li><a href="">

                                            <i data-feather="eye"></i>
                                            VIEW</a></li>
                            </li>

                            </ul>



                            </li>

                            <li class="sidebar-main-title">
                                <div>
                                    <h6>Diamond</h6>
                                </div>
                            </li>
                            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i
                                        data-feather="list"></i><span>Items</span></a>
                                <ul class="nav-submenu menu-content">
                                    <li><a href="Add_Item.php?Name=Diamond">

                                            <i data-feather="plus"></i>
                                            ADD</a>

                                    </li>

                                    <li><a href="">

                                            <i data-feather="eye"></i>
                                            VIEW</a></li>
                            </li>

                            </ul>



                            </li>




                            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i
                                        data-feather="list"></i><span>Products</span></a>
                                <ul class="nav-submenu menu-content">
                                    <li><a href="Add_Product.php?Name=Diamond">

                                            <i data-feather="plus"></i>
                                            ADD</a>

                                    </li>

                                    <li><a href="">

                                            <i data-feather="eye"></i>
                                            VIEW</a></li>
                            </li>

                            </ul>



                            </li>

                            <li class="sidebar-main-title">
                                <div>
                                    <h6>Silver</h6>
                                </div>
                            </li>
                            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i
                                        data-feather="list"></i><span>Items</span></a>
                                <ul class="nav-submenu menu-content">
                                    <li><a href="Add_Item.php?Name=Silver">

                                            <i data-feather="plus"></i>
                                            ADD</a>

                                    </li>

                                    <li><a href="">

                                            <i data-feather="eye"></i>
                                            VIEW</a></li>
                            </li>

                            </ul>



                            </li>




                            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i
                                        data-feather="list"></i><span>Products</span></a>
                                <ul class="nav-submenu menu-content">
                                    <li><a href="Add_Product.php?Name=Silver">

                                            <i data-feather="plus"></i>
                                            ADD</a>

                                    </li>

                                    <li><a href="">

                                            <i data-feather="eye"></i>
                                            VIEW</a></li>
                            </li>

                            </ul>



                            </li>
                            <li class="sidebar-main-title">
                                <div>
                                    <h6>Platinum</h6>
                                </div>
                            </li>
                            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i
                                        data-feather="list"></i><span>Items</span></a>
                                <ul class="nav-submenu menu-content">
                                    <li><a href="Add_Item.php?Name=Platinum">

                                            <i data-feather="plus"></i>
                                            ADD</a>

                                    </li>

                                    <li><a href="">

                                            <i data-feather="eye"></i>
                                            VIEW</a></li>
                            </li>

                            </ul>



                            </li>




                            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i
                                        data-feather="list"></i><span>Products</span></a>
                                <ul class="nav-submenu menu-content">
                                    <li><a href="Add_Product.php?Name=Platinum">

                                            <i data-feather="plus"></i>
                                            ADD</a>

                                    </li>

                                    <li><a href="">

                                            <i data-feather="eye"></i>
                                            VIEW</a></li>
                            </li>

                            </ul>



                            </li>

                            </ul>
                        </div>
                        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
                    </div>
                </nav>
            </header>