<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>
            My First Website
        </title>
        <link type="text/css" rel="stylesheet" href='css/bootstrap.min.css'>
        <link type="text/css" rel="stylesheet" href='css/sw-component-design.ba9b93a4.css'>
        <link type='text/css' rel='stylesheet' href='https://fonts.googleapis.com/css?family=Abhaya Libre'>
        <link rel='stylesheet' href='css/new.css' type='text/css'>
</head>
<body>







        <script type="text/javascript" src='js/jquery-3.5.1.min.js'>
        
        </script> 
        <script type="text/javascript" src='js/bootstrap.bundle.min.js'>
        
        </script> 
        <script type="text/javascript" src='js/all.js'>
        
        </script>
</body>
</html>